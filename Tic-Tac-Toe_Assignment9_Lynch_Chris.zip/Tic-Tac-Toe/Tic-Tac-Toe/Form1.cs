﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_Tac_Toe
{
    public partial class TicTacToe : Form
    {
        public TicTacToe()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void newGameButton_Click(object sender, EventArgs e)
        {
            int[,] boxNumber = new int[3, 3];
            Random rand = new Random();

            for(int i = 0; i< 3; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    boxNumber[i, j] = rand.Next(0, 2);
                }
            }

            if (boxNumber[0, 0] == 1)
            {
                label1.Text = "X";
            }

            else
            {
                label1.Text = "O";
            }

            if (boxNumber[0, 1] == 1)
            {
                label2.Text = "X";
            }

            else
            {
                label2.Text = "O";
            }

            if (boxNumber[0, 2] == 1)
            {
                label3.Text = "X";
            }

            else
            {
                label3.Text = "O";
            }

            if (boxNumber[1, 0] == 1)
            {
                label4.Text = "X";
            }

            else
            {
                label4.Text = "O";
            }

            if (boxNumber[1, 1] == 1)
            {
                label5.Text = "X";
            }

            else
            {
                label5.Text = "O";
            }

            if (boxNumber[1, 2] == 1)
            {
                label6.Text = "X";
            }

            else
            {
                label6.Text = "O";
            }

            if (boxNumber[2, 0] == 1)
            {
                label7.Text = "X";
            }

            else
            {
                label7.Text = "O";
            }

            if (boxNumber[2, 1] == 1)
            {
                label8.Text = "X";
            }

            else
            {
                label8.Text = "O";
            }

            if (boxNumber[2, 2] == 1)
            {
                label9.Text = "X";
            }

            else
            {
                label9.Text = "O";
            }

            if 
                (((boxNumber[0, 0] == 1) && (boxNumber[0, 1] == 1) && (boxNumber[0, 2] == 1))
                || ((boxNumber[1, 0] == 1) && (boxNumber[1, 1] == 1) && (boxNumber[1, 2] == 1)) 
                || ((boxNumber[2, 0] == 1) && (boxNumber[2, 1] == 1) && (boxNumber[2, 2] == 1)) 
                || ((boxNumber[0, 0] == 1) && (boxNumber[1, 1] == 1) && (boxNumber[2, 2] == 1)) 
                || ((boxNumber[0, 0] == 1) && (boxNumber[1, 0] == 1) && (boxNumber[2, 0] == 1)) 
                || ((boxNumber[0, 1] == 1) && (boxNumber[1, 1] == 1) && (boxNumber[2, 1] == 1)) 
                || ((boxNumber[0, 2] == 1) && (boxNumber[1, 2] == 1) && (boxNumber[2, 2] == 1)))
            {
                winnerLabel.Text = "Player X won!";
            }

            else if
                (((boxNumber[0, 0] == 0) && (boxNumber[0, 1] == 0) && (boxNumber[0, 2] == 0)) 
                || ((boxNumber[1, 0] == 0) && (boxNumber[1, 1] == 0) && (boxNumber[1, 2] == 0)) 
                || ((boxNumber[2, 0] == 0) && (boxNumber[2, 1] == 0) && (boxNumber[2, 2] == 0)) 
                || ((boxNumber[0, 0] == 0) && (boxNumber[1, 1] == 0) && (boxNumber[2, 2] == 0)) 
                || ((boxNumber[0, 0] == 0) && (boxNumber[1, 0] == 0) && (boxNumber[2, 0] == 0)) 
                || ((boxNumber[0, 1] == 0) && (boxNumber[1, 1] == 0) && (boxNumber[2, 1] == 0)) 
                || ((boxNumber[0, 2] == 0) && (boxNumber[1, 2] == 0) && (boxNumber[2, 2] == 0)))

            {
                winnerLabel.Text = "Player O won!";
            }
            else
            {
                winnerLabel.Text = "Game draw.";
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";
            label7.Text = "";
            label8.Text = "";
            label9.Text = "";
            winnerLabel.Text = "Cleared board.";
        }
    }
}
